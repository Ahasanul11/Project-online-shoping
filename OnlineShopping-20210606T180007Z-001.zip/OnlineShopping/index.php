<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce - Home</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'navbar.php'; ?>

    <!-- Product section start -->
    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Featured Product</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php
                    $query = "SELECT * FROM products ORDER BY cid";
                    $result = mysqli_query($con,$query);
                    
                    $fp = 0;

                    while($row=mysqli_fetch_assoc($result)){
                ?>
                <div class="col-md-3">
                    <div class="product-item">
                        <div class="product-img">
                            <img src="images/products/<?php echo $row['pimage'] ?>" alt="img">
                        </div>
                        <div class="product-content">
                            <div class="product-text">
                                <a class="product-title">
                                    <?php echo $row['pname']; ?>
                                </a>
                                <?php
                                    $cid = $row['cid'];
                                    $cquery = "SELECT * FROM categories WHERE cid = '$cid'";
                                    $cresult = mysqli_query($con, $cquery);
                                    $crow = mysqli_fetch_assoc($cresult);
                                ?>
                                <p class="product-size"><?php echo $crow['cname']; ?></p>
                            </div>
                            <ul class="product-price">
                                <li>
                                    <del>
                                        <span>৳ </span>
                                        <?php echo $row['rprice']; ?>
                                    </del>
                                </li>
                                <li>
                                    <span>৳ </span>
                                    <?php echo $row['sprice']; ?>
                                </li>
                            </ul>
                            <div class="product-button">
                                <a href="#" class="btn btn-cart">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    $fp++;
                    if($fp==4){
                        break;
                    }
                } 
                
                ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="section-button">
                        <a href="#" class="btn btn-link">View More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product section end -->
    <!-- offer section start -->
    <section class="offer standard-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-heading">
                            <h2>Why choose us?</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <div class="offer-item">
                            <div class="offer-icon">
                                <i class="fa fa-truck"></i>
                            </div>
                            <div class="offer-content">
                                <h2>Fastest Delivery</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="offer-item">
                            <div class="offer-icon">
                                <i class="fa fa-lock"></i>
                            </div>
                            <div class="offer-content">
                                <h2>Secure Payments</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="offer-item">
                            <div class="offer-icon">
                                <i class="fa fa-gift"></i>
                            </div>
                            <div class="offer-content">
                                <h2>New Products</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="offer-item">
                            <div class="offer-icon">
                                <i class="fa fa-smile-o"></i>
                            </div>
                            <div class="offer-content">
                                <h2>Happy Customers</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <!-- offer section end -->
    <!-- product section start -->
    <section class="standard-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-heading">
                            <h2>Latest Products</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                <?php
                    $query = "SELECT * FROM products ORDER BY pid DESC";
                    $result = mysqli_query($con,$query);
                    
                    $lp = 0;

                    while($row=mysqli_fetch_assoc($result)){
                ?>
                <div class="col-md-3">
                    <div class="product-item">
                        <div class="product-img">
                            <img src="images/products/<?php echo $row['pimage'] ?>" alt="img">
                        </div>
                        <div class="product-content">
                            <div class="product-text">
                                <a class="product-title">
                                    <?php echo $row['pname']; ?>
                                </a>
                                <?php
                                    $cid = $row['cid'];
                                    $cquery = "SELECT * FROM categories WHERE cid = '$cid'";
                                    $cresult = mysqli_query($con, $cquery);
                                    $crow = mysqli_fetch_assoc($cresult);
                                ?>
                                <p class="product-size"><?php echo $crow['cname']; ?></p>
                            </div>
                            <ul class="product-price">
                                <li>
                                    <del>
                                        <span>৳ </span>
                                        <?php echo $row['rprice']; ?>
                                    </del>
                                </li>
                                <li>
                                    <span>৳ </span>
                                    <?php echo $row['sprice']; ?>
                                </li>
                            </ul>
                            <div class="product-button">
                                <a href="#" class="btn btn-cart">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    $fp++;
                    if($fp==12){
                        break;
                    }
                } 
                
                ?>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-button">
                            <a href="#" class="btn btn-link">View More</a>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <!-- product section end -->

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>