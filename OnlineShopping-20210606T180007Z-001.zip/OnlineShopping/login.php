<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);

    if(isset($_POST['login'])){
        $uname = $_POST['uname'];
        $upass = $_POST['upass'];

        $query = "SELECT * FROM users WHERE uname='$uname' AND upass='$upass'";
        $result = mysqli_query($con,$query);
        $row=mysqli_fetch_assoc($result);
        
        $user_id=$row['uid'];
    
        if(mysqli_num_rows($result)==1)
        {
            $_SESSION['user_id']=$user_id;
            header("Location: user-page.php");
        }
    }

    if(isset($_POST['signup'])){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $uname = $_POST['uname'];
        $upass = $_POST['upass'];

        $query = "INSERT INTO users(uname, upass, fname, lname) VALUES('$uname','$upass','$fname','$lname')";
        $result = mysqli_query($con,$query);
    
        if($result)
        {
            header("Location: login.php");
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce - Home</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'navbar.php'; ?>

    <!-- Account section start -->
    <section class="account standard-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <div class="account-form">
                            <h2 class="account-title">Register</h2>
                            <form action="" method="post">
                                <label for="fname">First Name <span>*</span></label>
                                <input type="text" name="fname" id="fnamae" required>
                                <label for="lname">Last Name <span>*</span></label>
                                <input type="text" name="lname" id="lname" required>
                                <label for="uname">Email / Phone <span>*</span></label>
                                <input type="text" name="uname" id="unamae" required>
                                <label for="upass">Create Password <span>*</span></label>
                                <input type="password" name="upass" id="upass" required>
                                <input type="submit" name="signup" value="Register">
                            </form>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="account-form">
                            <h2 class="account-title">Login</h2>
                            <form action="" method="post">
                                <label for="uname">Username <span>*</span></label>
                                <input type="text" name="uname" id="unamae" required>
                                <label for="upass">Password <span>*</span></label>
                                <input type="password" name="upass" id="upass" required>
                                <input type="submit" name="login" value="Login">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <!-- Account section end -->

    <?php include 'footer.php'; ?>
    
    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>