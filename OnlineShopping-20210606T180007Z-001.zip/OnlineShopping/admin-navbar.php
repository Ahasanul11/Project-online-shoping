 <!-- header section start -->
   <header class="header-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <div class="header-logo">
                        <a href="admin-page.php">
                            <img src="images/icons/Logo.png" alt="Logo">
                        </a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="header-menu">
                        <ul class="main-menu">
                            <li><a href="admin-page.php">Home</a></li>
                            <li><a href="admin-profile.php"><?php echo $_SESSION['admin_name']; ?></a></li>
                            <li><a href="category.php">Category</a></li>
                            <li><a href="product.php">Product</a></li>
                            <li><a href="view-users.php">Customers</a></li>
                            <li><a href="#">Contact</a></li>
                            <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>     
            </div>
        </div>
    </header>
    <!-- header section end -->
   