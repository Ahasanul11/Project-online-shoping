<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);

    $user_id=$_SESSION['user_id'];

    $query = "SELECT * FROM users WHERE uid='$user_id'";
    $result = mysqli_query($con,$query);
    $row=mysqli_fetch_assoc($result);

    $profile_name=$row['fname'] . " " . $row['lname'];

    $pid = $_REQUEST['id'];
    $pquery = "SELECT * FROM products WHERE pid = '$pid'";
    $presult = mysqli_query($con,$pquery);
    $prow=mysqli_fetch_assoc($presult);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce - Home</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'user-navbar.php'; ?>

    <!-- Product section start -->
    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="product-details-image">
                        <img src="images/products/<?php echo $prow['pimage']; ?>" alt="Product Photo">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="product-details-content">
                        <h2 class="product-details-title"><?php echo $prow['pname']; ?></h2>
                        <?php
                            $cid = $prow['cid'];
                            $cquery = "SELECT * FROM categories WHERE cid = '$cid'";
                            $cresult = mysqli_query($con, $cquery);
                            $crow = mysqli_fetch_assoc($cresult);
                        ?>
                        <table class="product-details-info">
                            <tr>
                                <th>Product Name:</th>
                                <td><?php echo $prow['pname']; ?></td>
                            </tr>
                            <tr>
                                <th>Product Category:</th>
                                <td><?php echo $crow['cname']; ?></td>
                            </tr>
                            <tr>
                                <th>Price:</th>
                                <td><span>৳ </span><?php echo $prow['sprice']; ?></td>
                            </tr>
                            <tr>
                                <th>Quantity:</th>
                                <td>
                                    <input type="number" class="order-unit" name="unit" id="unit" min="1" value="1">
                                </td>
                            </tr>
                        </table>
                        <a href="#" class="btn btn-cart">Add to Cart</a>
                        <br><br>
                        <div class="product-details-about">
                            <h2>Have questions about this product?</h2>
                            <p>
                                <i class="fa fa-phone"></i> 01234-567890
                            </p>
                        </div>
                    </div>                    
                </div>
            </div>
            <br><br><br>
            <div class="row">
                <div class="col-md-12">
                    <div class="review-content">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="one-tab" data-bs-toggle="tab" data-bs-target="#one" type="button" role="tab" aria-controls="one" aria-selected="true">
                                    Description
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="one" role="tabpanel" aria-labelledby="one-tab">
                                <div class="review__item">
                                    <br>
                                    <p class="review-desc"><?php echo $prow['sdesc']; ?></p>
                                    <p class="review-desc"><?php echo $prow['ldesc']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product section end -->
    <!-- product section start -->
    <section class="standard-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-heading">
                            <h2>Related Products</h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                <?php
                    $query = "SELECT * FROM products WHERE cid = '$cid' ORDER BY pid DESC";
                    $result = mysqli_query($con,$query);
                    
                    $lp = 0;

                    while($row=mysqli_fetch_assoc($result)){
                ?>
                <div class="col-md-3">
                    <div class="product-item">
                        <div class="product-img">
                            <img src="images/products/<?php echo $row['pimage'] ?>" alt="img">
                        </div>
                        <div class="product-content">
                            <div class="product-text">
                                <a class="product-title">
                                    <?php echo $row['pname']; ?>
                                </a>
                                <?php
                                    $cid = $row['cid'];
                                    $cquery = "SELECT * FROM categories WHERE cid = '$cid'";
                                    $cresult = mysqli_query($con, $cquery);
                                    $crow = mysqli_fetch_assoc($cresult);
                                ?>
                                <p class="product-size"><?php echo $crow['cname']; ?></p>
                            </div>
                            <ul class="product-price">
                                <li>
                                    <del>
                                        <span>৳ </span>
                                        <?php echo $row['rprice']; ?>
                                    </del>
                                </li>
                                <li>
                                    <span>৳ </span>
                                    <?php echo $row['sprice']; ?>
                                </li>
                            </ul>
                            <div class="product-button">
                                <a href="single-product.php?id=<?php echo $row["pid"]; ?>" class="btn btn-cart">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    $fp++;
                    if($fp==4){
                        break;
                    }
                } 
                
                ?>
                </div>
            </div>
    </section>
    <!-- product section end -->

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>