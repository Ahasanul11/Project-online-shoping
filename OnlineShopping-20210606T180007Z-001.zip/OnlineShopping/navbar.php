 <!-- header section start -->
   <header class="header-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <div class="header-logo">
                        <a href="index.php">
                            <img src="images/icons/Logo.png" alt="Logo">
                        </a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="header-menu">
                        <ul class="main-menu">
                            <li><a href="index.php">Home</a></li>
                            <li><a href="#">About</a></li>
                            <li><a href="#">Product</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                        <ul>
                            <li>
                                <a href="login.php" class="btn btn-border bg-color">Login / Register</a>
                            </li>
                        </ul>
                    </div>
                </div>     
            </div>
        </div>
    </header>
    <!-- header section end -->
   