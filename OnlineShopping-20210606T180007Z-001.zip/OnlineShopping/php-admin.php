<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Account section start -->
    <section class="account standard-section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-5">
                        <div class="account-form">
                            <h2 class="account-title">Login</h2>
                            <form method="post" action="">
                                <label for="uname">Admin Username <span>*</span></label>
                                <input type="text" name="uname" id="unamae" required>
                                <label for="upass">Password <span>*</span></label>
                                <input type="password" name="upass" id="upass" required>
                                <input type="submit" name="login" value="Login">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <!-- Account section end -->

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>

<?php
    if(isset($_POST['login']))
    {
        session_start();
        $uname = $_POST['uname'];
        $upass = $_POST['upass'];

        $query = "SELECT * FROM admin WHERE aname='$uname' AND apass='$upass'";
        $result = mysqli_query($con,$query);

        $row=mysqli_fetch_assoc($result);
        $admin_name=$row['aname'];
        $admin_password=$row['apass'];

        if(mysqli_num_rows($result)==1)
        {
            $_SESSION['aid']=$row['aid'];
            $_SESSION['admin_name']=$admin_name;
            $_SESSION['admin_password']=$admin_password;
            header("Location: admin-page.php");
        }
    }
?>