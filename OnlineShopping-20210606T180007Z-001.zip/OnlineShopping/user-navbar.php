<!-- header section start -->
<header class="header-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-3">
                <div class="header-logo">
                    <a href="user-page.php">
                        <img src="images/icons/Logo.png" alt="Logo">
                    </a>
                </div>
            </div>
            <div class="col-md-9">
                <div class="header-menu">
                    <ul class="main-menu">
                        <li><a href="user-page.php">Home</a></li>
                        <li><a href="user-profile.php"><?php echo $profile_name; ?></a></li>
                        <li><a href="#">Product</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>     
        </div>
    </div>
</header>
<!-- header section end -->