<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);

    $aid = $_SESSION['aid'];
    $query = "SELECT * FROM admin WHERE aid = '$aid'";
    $result = mysqli_query($con,$query);
    $row=mysqli_fetch_assoc($result);

    if(isset($_POST['save'])){
        $uname = $_POST['uname'];
        $upass = $_POST['upass'];
        $upquery="UPDATE admin SET aname = '$uname' , apass = '$upass' WHERE aid = '$aid'";
        $upresult=mysqli_query($con,$upquery);
        $row = mysqli_fetch_assoc($upresult);
        
        if($upresult){
            header("Location: admin-profile.php");
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'admin-navbar.php'; ?>

    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Admin Profile</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="admin-profile">
                        <form action="" method="post">
                            <div class="mb-3 row">
                                <label for="staticEmail" class="col-sm-2 col-form-label">ID</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly class="form-control-plaintext" id="staticEmail" value="<?php echo $row['aid']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="uname" class="col-sm-2 col-form-label">Username</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="uname" id="uname" value="<?php echo $row['aname']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="upass" class="col-sm-2 col-form-label">Password</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="upass" id="upass" value="<?php echo $row['apass']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row justify-content-center">
                            <input type="submit" class="btn btn-edit" name="save" value="Save Changes">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>