<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);

    $query = "SELECT * FROM categories";
    $result = mysqli_query($con,$query);
    $total_category = mysqli_num_rows($result);

    $query = "SELECT * FROM products";
    $result = mysqli_query($con,$query);
    $total_product = mysqli_num_rows($result);

    $query = "SELECT * FROM users";
    $result = mysqli_query($con,$query);
    $total_users = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'admin-navbar.php'; ?>

    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Admin Dashboard</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="status-box">
                        <h2><?php echo $total_category; ?></h2>
                        <p>Total Category</p>
                        <a href="category.php" class="text-link">
                            More info
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="status-box">
                        <h2><?php echo $total_product; ?></h2>
                        <p>Total Product</p>
                        <a href="product.php" class="text-link">
                            More info
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="status-box">
                        <h2><?php echo $total_users; ?></h2>
                        <p>Customers</p>
                        <a href="view-users.php" class="text-link">
                            More info
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="status-box">
                        <h2>3</h2>
                        <p>Orders</p>
                        <a href="#" class="text-link">
                            More info
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>