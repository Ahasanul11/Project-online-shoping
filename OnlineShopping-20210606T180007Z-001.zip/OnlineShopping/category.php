<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'admin-navbar.php'; ?>

    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Category</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                   <!-- Button trigger modal -->
                    <button type="button" class="btn btn-edit" data-toggle="modal" data-target="#exampleModalCenter">
                        <i class="fa fa-plus"></i>
                        New
                    </button>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Add New Category</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="" method="post">
                                    <label for="cname">Category Name</label>
                                    <input type="text" name="cname" id="cname" required>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-delete" data-dismiss="modal">
                                    <i class="fa fa-close"></i>
                                    Close
                                </button>
                                <input type="submit" class="btn btn-edit" name="save" value="Save Changes">
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>

                    <?php
                        if(isset($_POST['save'])){
                            $cname = $_POST['cname'];
                            $query="INSERT INTO `categories`(`cname`) VALUES ('$cname')";
                            $result=mysqli_query($con,$query);
                            if($result)
                            {
                                header('Location: category.php');
                            }
                            else
                            {
                                echo "OPPS!!! Failed to Add New Category.";
                            }
                        }
                    ?>

                    <div class="category-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Category Name</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $query = "SELECT * FROM categories";
                                    $result = mysqli_query($con,$query);
                                    
                                    while($row=mysqli_fetch_assoc($result)){
                                ?>
                                <tr>
                                    <td><?php echo $row['cname']; ?></td>
                                    <td>
                                        <a href="edit-category.php?id=<?php echo $row["cid"]; ?>" class="btn btn-edit">
                                            <i class="fa fa-edit"></i>
                                            Edit
                                        </a>
                                
                                        <a href="delete-category.php?id=<?php echo $row["cid"]; ?>" class="btn btn-delete">
                                            <i class="fa fa-trash"></i>
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>