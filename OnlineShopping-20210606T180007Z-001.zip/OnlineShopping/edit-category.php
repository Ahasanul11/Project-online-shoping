<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);

    $cid = $_REQUEST['id'];

    $query = "SELECT * FROM categories WHERE cid = '$cid'";
    $result = mysqli_query($con,$query);
    $row = mysqli_fetch_assoc($result);

    if(isset($_POST['save'])){
        $cname = $_POST['cname'];
        $upquery="UPDATE categories SET cname = '$cname' WHERE cid = '$cid'";
        $upresult=mysqli_query($con,$upquery);
        $row = mysqli_fetch_assoc($result);
       
        if($upresult){
            header("Location: category.php");
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'admin-navbar.php'; ?>

    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Update Category</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form action="" method="post">
                        <div class="mb-3">
                            <label for="cname" class="form-label">Category Name</label>
                            <input type="text" class="form-control" name="cname" id="cname" value="<?php echo $row['cname']; ?>" required>
                        </div>
                        <input type="submit" class="form-control btn btn-edit" name="save" value="Save Changes">
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>