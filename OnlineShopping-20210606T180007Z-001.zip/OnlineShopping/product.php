<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'admin-navbar.php'; ?>

    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Product</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-edit" data-toggle="modal" data-target="#exampleModalCenter">
                        <i class="fa fa-plus"></i>
                        New
                    </button>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Add New Product</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="mb-3 row">
                                        <label for="pname" class="col-sm-2 col-form-label">Product Name<span>*</span></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="pname" id="pname" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 row">
                                        <label for="cname" class="col-sm-2 col-form-label">Category<span>*</span></label>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="cname" id="cname" required>
                                                <option value="">Select Category</option>
                                                <?php
                                                    $acquery = "SELECT * FROM categories";
                                                    $acresult = mysqli_query($con,$acquery);
                                                    
                                                    while($acrow=mysqli_fetch_assoc($acresult)){
                                                ?>
                                                <option value="<?php echo $acrow['cid']; ?>"><?php echo $acrow['cname']; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-3 row">
                                        <label for="pimage" class="col-sm-2 col-form-label">Product Photo<span>*</span></label>
                                        <div class="col-sm-10">
                                            <input type="file" class="form-control" name="pimage" id="pimage" required>
                                        </div>
                                    </div>
                                    <div class="mb-3 row">
                                        <label for="sdesc" class="col-sm-2 col-form-label">Short Description<span>*</span></label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" name="sdesc" id="sdesc" cols="30" rows="3" required></textarea>
                                        </div>
                                    </div>
                                    <div class="mb-3 row">
                                        <label for="ldesc" class="col-sm-2 col-form-label">Long Description<span>*</span></label>
                                        <div class="col-sm-10">
                                        <textarea class="form-control" name="ldesc" id="ldesc" cols="30" rows="3" required></textarea>
                                        </div>
                                    </div>
                                    <div class="mb-3 row">
                                        <label for="rprice" class="col-sm-2 col-form-label">Regular Price</label>
                                        <div class="col-sm-10">
                                            <input type="number" class="form-control" name="rprice" id="rprice">
                                        </div>
                                    </div>
                                    <div class="mb-3 row">
                                        <label for="sprice" class="col-sm-2 col-form-label">Sale Price<span>*</span></label>
                                        <div class="col-sm-10">
                                            <input type="number" class="form-control" name="sprice" id="sprice" required>
                                        </div>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-delete" data-dismiss="modal">
                                    <i class="fa fa-close"></i>
                                    Close
                                </button>
                                <input type="submit" class="btn btn-edit" name="save" value="Save Changes">
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>

                    <?php
                        if(isset($_POST['save'])){
                            
                            $pname = $_POST['pname'];
                            $cid = $_POST['cname'];


                            $pimagename = $_FILES['pimage']['name'];
                            $pimgetmpname = $_FILES['pimage']['tmp_name'];
                            move_uploaded_file($pimgetmpname,'images/products/'.$pimagename);
                            
                            $sdesc = $_POST['sdesc'];
                            $ldesc = $_POST['ldesc'];
                            $rprice = $_POST['rprice'];
                            $sprice = $_POST['sprice'];

                            $query="INSERT INTO products(cid, pimage, pname, sdesc, ldesc, rprice, sprice) VALUES('$cid','$pimagename','$pname','$sdesc','$ldesc','$rprice','$sprice')";
                            $result=mysqli_query($con,$query);
                            if($result)
                            {
                                header('Location: product.php');
                            }
                            else
                            {
                                echo "OPPS!!! Failed to Add New Product.";
                            }
                        }
                    ?>

                    <div class="category-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Photo</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Catogory</th>
                                    <th scope="col">Short Description</th>
                                    <th scope="col">Long Description</th>
                                    <th scope="col">Regular Price</th>
                                    <th scope="col">Sale Price</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $query = "SELECT * FROM products ORDER BY pid DESC";
                                    $result = mysqli_query($con,$query);
                                    
                                    while($row=mysqli_fetch_assoc($result)){
                                ?>
                                <tr>
                                    <td width='5%'><?php echo $row['pid']; ?></td>
                                    <td width='15%'><img src="images/products/<?php echo $row['pimage'] ?>" height="150px" width="150px" alt="product image"></td>
                                    <td width='10%'><?php echo $row['pname']; ?></td>

                                    <?php
                                        $cid = $row['cid'];
                                        $cquery = "SELECT * FROM categories WHERE cid = '$cid'";
                                        $cresult = mysqli_query($con, $cquery);
                                        $crow = mysqli_fetch_assoc($cresult);
                                    ?>

                                    <td width='10%'><?php echo $crow['cname']; ?></td>
                                
                                    <td width='10%'><?php echo $row['sdesc']; ?></td>
                                    <td width='10%'><?php echo $row['ldesc']; ?></td>
                                    <td width='5%'><?php echo $row['rprice']; ?></td>
                                    <td width='5%'><?php echo $row['sprice']; ?></td>
                                    <td width='20%'>
                                        <a href="edit-product.php?id=<?php echo $row["pid"]; ?>" class="btn btn-edit">
                                            <i class="fa fa-edit"></i>
                                            Edit
                                        </a>
                                
                                        <a href="#?id=<?php echo $row["cid"]; ?>" class="btn btn-delete">
                                            <i class="fa fa-trash"></i>
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>