<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'admin-navbar.php'; ?>

    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Customers</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="category-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Photo</th>
                                    <th scope="col">First Name</th>
                                    <th scope="col">Last Name</th>
                                    <th scope="col">Address</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Password</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $query = "SELECT * FROM users";
                                    $result = mysqli_query($con,$query);
                                    
                                    while($row=mysqli_fetch_assoc($result)){
                                ?>
                                <tr>
                                    <td width='5%'><?php echo $row['uid']; ?></td>
                                    <td width='15%'><img src="images/products/<?php echo $row['uimage'] ?>" height="150px" width="150px" alt="Customer Photo"></td>
                                    <td width='10%'><?php echo $row['fname']; ?></td>
                                    <td width='10%'><?php echo $row['lname']; ?></td>
                                    <td width='10%'><?php echo $row['address']; ?></td>
                                    <td width='10%'><?php echo $row['uname']; ?></td>
                                    <td width='5%'><?php echo $row['upass']; ?></td>
                                    <td width='20%'>
                                        <a href="#?id=<?php echo $row["uid"]; ?>" class="btn btn-delete">
                                            <i class="fa fa-trash"></i>
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>