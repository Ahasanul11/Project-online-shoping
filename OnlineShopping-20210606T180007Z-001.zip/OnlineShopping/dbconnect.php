<?php
	$con = new mysqli("localhost","root","","online_shopping");
	if(!$con)
	{
		echo "failed";
	}
?>