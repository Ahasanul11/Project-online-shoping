<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);

    $user_id=$_SESSION['user_id'];

    $query = "SELECT * FROM users WHERE uid='$user_id'";
    $result = mysqli_query($con,$query);
    $row=mysqli_fetch_assoc($result);

    $profile_name=$row['fname'] . " " . $row['lname'];

    if (isset($_POST['save'])) {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $address = $_POST['address'];
        $upass = $_POST['upass'];

        $upquery="UPDATE users SET fname = '$fname' , lname = '$lname', address = '$address', upass = '$upass' WHERE uid = '$user_id'";
        $upresult=mysqli_query($con,$upquery);
        $row = mysqli_fetch_assoc($upresult);
        
        if($upresult){
            header("Location: user-profile.php");
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce - Home</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'user-navbar.php'; ?>

    <!-- Product section start -->
    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>My Profile</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="admin-profile">
                        <form action="" method="post">
                            <div class="mb-3 row">
                                <label for="staticEmail" class="col-sm-2 col-form-label">ID</label>
                                <div class="col-sm-10">
                                    <input type="text" disabled class="form-control" id="staticEmail" value="<?php echo $row['uid']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="fname" class="col-sm-2 col-form-label">First Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="fname" id="fname" value="<?php echo $row['fname']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="lname" class="col-sm-2 col-form-label">Last Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="lname" id="lname" value="<?php echo $row['lname']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="address" class="col-sm-2 col-form-label">Address</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" name="address" cols="30" rows="4" value="<?php echo $row['address']; ?>"><?php echo $row['address']; ?></textarea>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="uname" class="col-sm-2 col-form-label">Username</label>
                                <div class="col-sm-10">
                                    <input type="text" disabled class="form-control" name="uname" id="uname" value="<?php echo $row['uname']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="upass" class="col-sm-2 col-form-label">Password</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="upass" id="upass" value="<?php echo $row['upass']; ?>">
                                </div>
                            </div>
                            <div class="mb-3 row justify-content-center">
                            <input type="submit" class="btn btn-edit" name="save" value="Save Changes">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product section end -->

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>