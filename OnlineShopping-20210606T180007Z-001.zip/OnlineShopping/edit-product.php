<?php
	include"dbconnect.php";
	session_start();		
    error_reporting(0);

    $pid = $_REQUEST['id'];
    $query = "SELECT * FROM products WHERE pid = '$pid'";
    $result = mysqli_query($con,$query);
    $row = mysqli_fetch_assoc($result);

    if(isset($_POST['change'])){
        $pimagename = $_FILES['pimage']['name'];
        $pimgetmpname = $_FILES['pimage']['tmp_name'];
        move_uploaded_file($pimgetmpname,'images/products/'.$pimagename);

        $upiquery="UPDATE products SET pimage='$pimagename' WHERE pid = '$pid'";
        $upiresult=mysqli_query($con,$upiquery);
        $row = mysqli_fetch_assoc($upiresult);
       
        if($upiresult){
            header("Location: product.php");
        }
    }

    if(isset($_POST['save'])){
        $pname = $_POST['pname'];
        $cid = $_POST['cname'];
        
        $sdesc = $_POST['sdesc'];
        $ldesc = $_POST['ldesc'];
        $rprice = $_POST['rprice'];
        $sprice = $_POST['sprice'];
    
        $upquery="UPDATE products SET cid='$cid', pname='$pname', sdesc='$sdesc', ldesc='$ldesc', rprice='$rprice', sprice='$sprice'  WHERE pid = '$pid'";
        $upresult=mysqli_query($con,$upquery);
        $row = mysqli_fetch_assoc($upresult);
       
        if($upresult){
            header("Location: product.php");
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    
    <!-- Favicon included -->
    <link rel="shortcut icon" href="images/icons/favicon.png" type="image/x-icon">
    
    <!-- All CSS files are here -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include 'admin-navbar.php'; ?>

    <section class="standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h2>Update Product</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="mb-3 row">
                            <label for="pname" class="col-sm-2 col-form-label">Product Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="pname" id="pname" value="<?php echo $row['pname']; ?>">
                            </div>
                         </div>
                         <div class="mb-3 row">
                            <label for="pname" class="col-sm-2 col-form-label">Category</label>
                            <div class="col-sm-10">
                                <select class="form-control" name="cname" id="cname" required>
                                    <?php
                                        $cid = $row['cid'];
                                        $cquery = "SELECT * FROM categories WHERE cid = '$cid'";
                                        $cresult = mysqli_query($con, $cquery);
                                        $crow = mysqli_fetch_assoc($cresult);
                                    ?>
                                    <option value="<?php echo $crow['cid']; ?>"><?php echo $crow['cname']; ?></option>

                                    <?php
                                        $acquery = "SELECT * FROM categories";
                                        $acresult = mysqli_query($con,$acquery);
                                                    
                                        while($acrow=mysqli_fetch_assoc($acresult)){
                                    ?>
                                    <option value="<?php echo $acrow['cid']; ?>"><?php echo $acrow['cname']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="pimage" class="col-sm-2 col-form-label">Product Photo</label>
                            <div class="col-sm-10">
                                <img src="images/products/<?php echo $row['pimage'] ?>" height="200px" width="200px" alt="product image">
                                <br>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-edit" data-toggle="modal" data-target="#exampleModalCenter">
                                    <i class="fa fa-share"></i>
                                    Change Photo
                                </button>
                            </div>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLongTitle">Update Product Photo</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                            <label for="pimage">Product Image</label>
                                            <input type="file" name="pimage" id="pimage">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-delete" data-dismiss="modal">
                                            <i class="fa fa-close"></i>
                                            Close
                                        </button>
                                        <input type="submit" class="btn btn-edit" name="change" value="Save Changes">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="sdesc" class="col-sm-2 col-form-label">Short Description</label>
                            <div class="col-sm-10">
                                <textarea class="form-control" name="sdesc" id="sdesc" cols="30" rows="3" value="<?php echo $row['sdesc']; ?>"><?php echo $row['sdesc']; ?></textarea>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="ldesc" class="col-sm-2 col-form-label">Long Description<span>*</span></label>
                            <div class="col-sm-10">
                                <textarea class="form-control" name="ldesc" id="ldesc" cols="30" rows="3" value="<?php echo $row['ldesc']; ?>"><?php echo $row['ldesc']; ?></textarea>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="rprice" class="col-sm-2 col-form-label">Regular Price</label>
                            <div class="col-sm-10">
                                <input type="number" class="form-control" name="rprice" id="rprice" value="<?php echo $row['rprice']; ?>">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="sprice" class="col-sm-2 col-form-label">Sale Price</label>
                            <div class="col-sm-10">
                                <input type="number" class="form-control" name="sprice" id="sprice" value="<?php echo $row['sprice']; ?>">
                            </div>
                        </div>
                        <input type="submit" class="form-control btn btn-edit" name="save" value="Save Changes">
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <!-- All Javascript files are here -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>