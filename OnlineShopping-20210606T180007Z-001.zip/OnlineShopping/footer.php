<!-- footer section start -->
<footer class="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <aside class="footer-info">
                            <div class="footer-logo">
                                <a href="index.html">
                                    <img src="images/icons/Logo.png" alt="Logo">
                                </a>
                            </div>
                            <div class="footer-info-text">
                                <h2>Online Shooping</h2>
                                <p>
                                    The rise of mobile devices transform the way we 
                                    consume information entirely and the world's most
                                    elevant channels such as Facebook. 
                                </p>
                            </div>
                        </aside>
                    </div>
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-4">
                                <aside class="footer-widget">
                                    <h2 class="widget-title">Our Product</h2>
                                    <ul class="widget-list">
                                        <li><a href="#">About Us</a></li>
                                        <li><a href="#">Delivery Information</a></li>
                                        <li><a href="#">Terms & Condition</a></li>
                                        <li><a href="#">Privacy Policy</a></li>
                                        <li><a href="#">Contact Us</a></li>
                                    </ul>
                                </aside>
                            </div>
                            <div class="col-md-4">
                                <aside class="footer-widget">
                                    <h2 class="widget-title">Online Shooping</h2>
                                    <ul class="widget-list">
                                        <li><a href="#">About Us</a></li>
                                        <li><a href="#">Delivery Information</a></li>
                                        <li><a href="#">Terms & Condition</a></li>
                                        <li><a href="#">Privacy Policy</a></li>
                                        <li><a href="#">Contact Us</a></li>
                                    </ul>
                                </aside>
                            </div>
                            <div class="col-md-4">
                                <aside class="footer-widget">
                                    <h2 class="widget-title">Download APP</h2>
                                    <ul class="widget-list">
                                        <li>
                                            <a href="#">
                                                <img src="images/icons/google-play.png" alt="img">
                                            </a>
                                        </li>
                                    </ul>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright-text">
                            <h2>Copyright &copy; <?php echo date('Y'); ?> onlineshooping | All rights reserved.</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer section end -->
    <!-- Scrool to top section start -->
    <div id="scroll-to-top">
        <div class="top-icon">
            <i class="fa fa-angle-up"></i>
        </div>
    </div>
    <!-- Scrool to top section end -->