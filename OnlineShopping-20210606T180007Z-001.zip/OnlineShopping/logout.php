<?php
	include "dbconnect.php";
	session_start();
	
	unset ($_SESSION["aid"]);
	unset ($_SESSION["user_id"]);
	
	session_destroy();

	header("Location: index.php");
?>